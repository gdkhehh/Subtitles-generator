
export interface Subtitle {
  id: string;
  start: number;
  end: number;
  text: string;
}

export type CaptionPreset = 'classic' | 'reels' | 'karaoke' | 'box' | 'neon' | 'big-center';

export type CaptionPosition = 'top' | 'center' | 'bottom';

export interface StyleConfig {
  preset: CaptionPreset;
  fontSize: number;
  color: string;
  bgColor: string;
  position: CaptionPosition;
  showEmojis: boolean;
  fontWeight: string;
  textTransform: 'none' | 'uppercase' | 'capitalize';
}

export interface UserPlan {
  isPremium: boolean;
  videosToday: number;
}
