
# AI Auto Subtitle Studio

## Folder Structure
- `/` - React Frontend (TypeScript + Tailwind)
- `/services/` - Gemini API Integration for AI Transcribing
- `/backend/` - Flask Server for FFmpeg and Local Whisper processing
- `/components/` - Shared UI elements
- `types.ts` - Interface definitions

## How to Run (Local)
1. **Frontend**: `npm install && npm start`
2. **Backend**: `pip install -r backend/requirements.txt` then `python backend/main.py`
3. **FFmpeg**: Ensure FFmpeg is installed and added to your system PATH.

## Deployment (Railway)
1. **Host Backend**: 
   - Use the Railway Python template. 
   - Add a Nixpack config to install `ffmpeg`.
   - Set env variables for Whisper model caching.
2. **Host Frontend**:
   - Link your GitHub repo.
   - Set `API_KEY` for Gemini in the Railway Environment variables.
3. **Scaling**: Use a GPU-enabled instance for faster Whisper transcription if needed.

## Features
- Hinglish Support via Gemini 3 / Whisper.
- Dynamic Previewing (WYSIWYG styling).
- Multi-style Presets (Neon, Reels, Karaoke).
