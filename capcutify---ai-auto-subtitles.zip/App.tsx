
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Upload, Play, Download, Settings, Edit3, Type as FontIcon, CheckCircle, Zap, Info, Clock, Trash2, Plus } from 'lucide-react';
import { Subtitle, StyleConfig, CaptionPreset, UserPlan } from './types';
import { PRESETS } from './constants';
import { generateSubtitles } from './services/geminiService';

const App: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [subtitles, setSubtitles] = useState<Subtitle[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [activeSubId, setActiveSubId] = useState<string | null>(null);
  const [userPlan, setUserPlan] = useState<UserPlan>({ isPremium: false, videosToday: 0 });
  const [style, setStyle] = useState<StyleConfig>({
    preset: 'classic',
    fontSize: 24,
    color: '#ffffff',
    bgColor: 'rgba(0,0,0,0.5)',
    position: 'bottom',
    showEmojis: true,
    fontWeight: '600',
    textTransform: 'none'
  });

  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (userPlan.videosToday >= 1 && !userPlan.isPremium) {
        alert("Free limit reached! Upgrade to Premium for unlimited videos.");
        return;
      }
      setVideoFile(file);
      setVideoUrl(URL.createObjectURL(file));
      setSubtitles([]);
    }
  };

  const startAutoSubtitles = async () => {
    if (!videoFile) return;
    setIsProcessing(true);
    try {
      const results = await generateSubtitles(videoFile);
      setSubtitles(results);
      setUserPlan(prev => ({ ...prev, videosToday: prev.videosToday + 1 }));
    } catch (error) {
      console.error(error);
      alert("Error generating subtitles. Check console for details.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const time = videoRef.current.currentTime;
      setCurrentTime(time);
      const active = subtitles.find(s => time >= s.start && time <= s.end);
      setActiveSubId(active?.id || null);
    }
  };

  const updateSubtitle = (id: string, updates: Partial<Subtitle>) => {
    setSubtitles(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const addSubtitle = () => {
    const newSub: Subtitle = {
      id: `manual-${Date.now()}`,
      start: currentTime,
      end: currentTime + 2,
      text: "New Caption"
    };
    setSubtitles(prev => [...prev, newSub].sort((a, b) => a.start - b.start));
  };

  const removeSubtitle = (id: string) => {
    setSubtitles(prev => prev.filter(s => s.id !== id));
  };

  const applyPreset = (presetKey: CaptionPreset) => {
    const presetValues = PRESETS[presetKey];
    if (presetValues) {
      setStyle(prev => ({ ...prev, preset: presetKey, ...presetValues }));
    }
  };

  const adjustAllTimestamps = (offset: number) => {
    setSubtitles(prev => prev.map(s => ({
      ...s,
      start: Math.max(0, s.start + offset),
      end: Math.max(0, s.end + offset)
    })));
  };

  const getPositionStyles = (pos: string) => {
    switch (pos) {
      case 'top': return 'top-10 items-start';
      case 'center': return 'top-1/2 -translate-y-1/2 items-center';
      default: return 'bottom-10 items-end';
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden bg-slate-950 text-slate-100">
      {/* LEFT: Video Preview Area */}
      <div className="flex-1 flex flex-col relative bg-black items-center justify-center p-4">
        {!videoUrl ? (
          <div className="max-w-md w-full border-2 border-dashed border-slate-700 rounded-3xl p-12 flex flex-col items-center justify-center text-center space-y-4 hover:border-blue-500 transition-colors cursor-pointer group relative">
            <input type="file" accept="video/*" onChange={handleFileUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
            <div className="p-4 bg-slate-900 rounded-full group-hover:scale-110 transition-transform">
              <Upload className="w-12 h-12 text-blue-500" />
            </div>
            <h2 className="text-xl font-bold">Upload Video</h2>
            <p className="text-slate-400">MP4 or MOV recommended (Max 25MB for free users)</p>
          </div>
        ) : (
          <div className="relative w-full max-w-2xl aspect-video rounded-xl overflow-hidden shadow-2xl bg-black">
            <video 
              ref={videoRef} 
              src={videoUrl} 
              onTimeUpdate={handleTimeUpdate}
              className="w-full h-full object-contain"
              controls 
            />
            
            {/* SUBTITLE OVERLAY */}
            <div className={`absolute inset-0 pointer-events-none flex flex-col justify-center px-10 ${getPositionStyles(style.position)}`}>
              {subtitles.map(sub => (
                activeSubId === sub.id && (
                  <div 
                    key={sub.id}
                    className="transition-all duration-200"
                    style={{
                      fontSize: `${style.fontSize}px`,
                      color: style.color,
                      backgroundColor: style.bgColor,
                      fontWeight: style.fontWeight,
                      textTransform: style.textTransform,
                      padding: '4px 12px',
                      borderRadius: '8px',
                      textAlign: 'center',
                      lineHeight: '1.2',
                      boxShadow: style.preset === 'neon' ? `0 0 15px ${style.color}` : 'none',
                      border: style.preset === 'neon' ? `2px solid ${style.color}` : 'none'
                    }}
                  >
                    {sub.text}
                  </div>
                )
              ))}
            </div>

            {/* WATERMARK */}
            {!userPlan.isPremium && (
              <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded text-xs font-bold text-white/80 border border-white/20">
                MADE WITH CAPCUTIFY AI
              </div>
            )}
          </div>
        )}

        {videoUrl && !subtitles.length && (
          <div className="mt-8">
            <button 
              onClick={startAutoSubtitles}
              disabled={isProcessing}
              className="flex items-center gap-2 px-8 py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 rounded-full font-bold text-lg shadow-lg shadow-blue-900/40 transition-all active:scale-95"
            >
              {isProcessing ? <Zap className="animate-pulse" /> : <Play />}
              {isProcessing ? "Processing with AI..." : "Generate Auto Subtitles"}
            </button>
          </div>
        )}
      </div>

      {/* RIGHT: Editing Controls Sidebar */}
      <div className="w-full lg:w-96 bg-slate-900 border-l border-slate-800 flex flex-col h-full overflow-hidden">
        {/* Tabs / Header */}
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h1 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 fill-white" />
            </div>
            CapCutify AI
          </h1>
          <button 
            onClick={() => setUserPlan(p => ({ ...p, isPremium: !p.isPremium }))}
            className={`text-xs px-2 py-1 rounded font-bold uppercase ${userPlan.isPremium ? 'bg-amber-500 text-black' : 'bg-slate-700 text-slate-300'}`}
          >
            {userPlan.isPremium ? 'PRO USER' : 'UPGRADE'}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-8 scrollbar-thin">
          {/* Subtitle List */}
          <section>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold flex items-center gap-2"><Edit3 size={18} /> Subtitles</h3>
              <div className="flex gap-2">
                 <button onClick={() => adjustAllTimestamps(-0.1)} className="p-1 hover:bg-slate-700 rounded"><Clock size={16} /> -</button>
                 <button onClick={() => adjustAllTimestamps(0.1)} className="p-1 hover:bg-slate-700 rounded"><Clock size={16} /> +</button>
                 <button onClick={addSubtitle} className="p-1 bg-blue-600/20 text-blue-400 hover:bg-blue-600/40 rounded"><Plus size={16} /></button>
              </div>
            </div>
            
            <div className="space-y-3">
              {subtitles.length === 0 ? (
                <div className="text-center py-10 bg-slate-800/50 rounded-xl text-slate-500 text-sm">
                  No subtitles generated yet.
                </div>
              ) : (
                subtitles.map(sub => (
                  <div 
                    key={sub.id} 
                    className={`p-3 rounded-xl border transition-all ${activeSubId === sub.id ? 'bg-blue-900/20 border-blue-500' : 'bg-slate-800 border-slate-700'}`}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-mono text-slate-500">{sub.start.toFixed(2)}s - {sub.end.toFixed(2)}s</span>
                      <button onClick={() => removeSubtitle(sub.id)} className="text-slate-500 hover:text-red-400"><Trash2 size={14}/></button>
                    </div>
                    <textarea 
                      value={sub.text}
                      onChange={(e) => updateSubtitle(sub.id, { text: e.target.value })}
                      className="w-full bg-transparent border-none focus:ring-0 text-sm resize-none"
                      rows={2}
                    />
                  </div>
                ))
              )}
            </div>
          </section>

          {/* Styling Presets */}
          <section>
            <h3 className="font-bold mb-4 flex items-center gap-2"><Settings size={18} /> Caption Styles</h3>
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(PRESETS) as CaptionPreset[]).map(key => (
                <button 
                  key={key}
                  onClick={() => applyPreset(key)}
                  className={`p-3 rounded-lg text-xs font-bold capitalize border-2 transition-all ${style.preset === key ? 'border-blue-500 bg-blue-500/10' : 'border-slate-700 bg-slate-800 hover:border-slate-600'}`}
                >
                  {key}
                </button>
              ))}
            </div>
          </section>

          {/* Detailed Customization */}
          <section className="space-y-4">
            <h3 className="font-bold mb-4 flex items-center gap-2"><FontIcon size={18} /> Custom Controls</h3>
            
            <div>
              <label className="text-xs text-slate-400 block mb-2">Font Size ({style.fontSize}px)</label>
              <input 
                type="range" min="12" max="64" value={style.fontSize} 
                onChange={(e) => setStyle(s => ({ ...s, fontSize: parseInt(e.target.value) }))}
                className="w-full accent-blue-500"
              />
            </div>

            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-xs text-slate-400 block mb-2">Text Color</label>
                <input 
                  type="color" value={style.color}
                  onChange={(e) => setStyle(s => ({ ...s, color: e.target.value }))}
                  className="w-full h-8 rounded cursor-pointer"
                />
              </div>
              <div className="flex-1">
                <label className="text-xs text-slate-400 block mb-2">Background</label>
                <input 
                  type="color" value={style.bgColor.startsWith('rgba') ? '#000000' : style.bgColor}
                  onChange={(e) => setStyle(s => ({ ...s, bgColor: e.target.value }))}
                  className="w-full h-8 rounded cursor-pointer"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-2">Position</label>
              <div className="flex bg-slate-800 rounded-lg p-1">
                {['top', 'center', 'bottom'].map(pos => (
                  <button 
                    key={pos}
                    onClick={() => setStyle(s => ({ ...s, position: pos as any }))}
                    className={`flex-1 py-1 text-[10px] font-bold uppercase rounded ${style.position === pos ? 'bg-slate-700 text-white' : 'text-slate-500'}`}
                  >
                    {pos}
                  </button>
                ))}
              </div>
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 space-y-2">
          <button className="w-full py-3 bg-white text-black font-black rounded-xl hover:bg-slate-200 transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg shadow-white/5">
            <Download size={20} />
            EXPORT FINAL VIDEO
          </button>
          <div className="flex justify-between items-center text-[10px] text-slate-500 px-1">
            <span className="flex items-center gap-1"><CheckCircle size={10} className="text-green-500" /> Hinglish Enabled</span>
            <span className="flex items-center gap-1"><Info size={10} /> {userPlan.isPremium ? 'Unlimited Access' : '1 Video / day limit'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
