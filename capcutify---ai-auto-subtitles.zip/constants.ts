
import { StyleConfig } from './types';

export const PRESETS: Record<string, Partial<StyleConfig>> = {
  classic: {
    fontSize: 24,
    color: '#ffffff',
    bgColor: 'rgba(0,0,0,0.5)',
    position: 'bottom',
    fontWeight: '600',
    textTransform: 'none'
  },
  reels: {
    fontSize: 32,
    color: '#ffff00',
    bgColor: 'transparent',
    position: 'center',
    fontWeight: '800',
    textTransform: 'uppercase'
  },
  karaoke: {
    fontSize: 28,
    color: '#ffffff',
    bgColor: 'rgba(255, 0, 100, 0.8)',
    position: 'bottom',
    fontWeight: '700',
    textTransform: 'uppercase'
  },
  box: {
    fontSize: 22,
    color: '#000000',
    bgColor: '#ffffff',
    position: 'bottom',
    fontWeight: '600',
    textTransform: 'none'
  },
  neon: {
    fontSize: 30,
    color: '#00ff00',
    bgColor: 'transparent',
    position: 'center',
    fontWeight: '800',
    textTransform: 'uppercase'
  }
};
