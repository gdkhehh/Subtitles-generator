
import { GoogleGenAI, Type } from "@google/genai";
import { Subtitle } from "../types";

export const generateSubtitles = async (videoBlob: Blob): Promise<Subtitle[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Convert blob to base64
  const reader = new FileReader();
  const base64Promise = new Promise<string>((resolve) => {
    reader.onloadend = () => {
      const base64data = (reader.result as string).split(',')[1];
      resolve(base64data);
    };
    reader.readAsDataURL(videoBlob);
  });
  
  const base64Video = await base64Promise;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: videoBlob.type,
              data: base64Video,
            },
          },
          {
            text: `Analyze the audio of this video and generate highly accurate subtitles. 
            Rules:
            1. Support English, Hindi, and Hinglish (mixed Hindi/English). 
            2. For Hinglish, keep the words exactly as spoken in Latin script.
            3. Provide exact start and end timestamps in seconds.
            4. Keep subtitle segments short (3-7 words each).
            5. Return ONLY a JSON array of objects with keys: start, end, text.`,
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            start: { type: Type.NUMBER, description: "Start time in seconds" },
            end: { type: Type.NUMBER, description: "End time in seconds" },
            text: { type: Type.STRING, description: "The transcribed text" },
          },
          required: ["start", "end", "text"],
        },
      },
    },
  });

  try {
    const rawJson = JSON.parse(response.text || "[]");
    return rawJson.map((s: any, index: number) => ({
      ...s,
      id: `sub-${index}-${Date.now()}`
    }));
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    return [];
  }
};
