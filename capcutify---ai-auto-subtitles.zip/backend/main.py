
import os
import subprocess
import whisper
import json
from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Load Whisper Model (Local)
# Note: In production, consider using 'base' or 'small' for speed, 'large' for accuracy.
model = whisper.load_model("base")

@app.route('/process', methods=['POST'])
def process_video():
    if 'video' not in request.files:
        return jsonify({"error": "No video uploaded"}), 400
    
    video = request.files['video']
    filename = secure_filename(video.filename)
    video_path = os.path.join(UPLOAD_FOLDER, filename)
    video.save(video_path)
    
    audio_path = os.path.join(UPLOAD_FOLDER, f"{filename}.mp3")
    
    # 1. Extract Audio using FFmpeg
    subprocess.run([
        'ffmpeg', '-i', video_path, '-q:a', '0', '-map', 'a', audio_path, '-y'
    ], check=True)
    
    # 2. Transcribe using Whisper
    # task="transcribe" detects language and keeps it (Hinglish works great with Whisper)
    result = model.transcribe(audio_path, verbose=False)
    
    # 3. Clean up
    os.remove(audio_path)
    
    subtitles = []
    for segment in result['segments']:
        subtitles.append({
            "id": segment['id'],
            "start": segment['start'],
            "end": segment['end'],
            "text": segment['text'].strip()
        })
        
    return jsonify({
        "subtitles": subtitles,
        "language": result['language']
    })

@app.route('/export', methods=['POST'])
def export_video():
    # Logic to burn subtitles into video using ffmpeg filter: subtitles=filename:force_style='FontName=Arial,FontSize=24'
    # For a high-end app, you'd generate an ASS file (Advanced Substation Alpha) for complex styling.
    data = request.json
    # Burn logic goes here...
    return jsonify({"message": "Export logic simulated. Requires FFmpeg on host."})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
